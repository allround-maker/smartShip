#!/usr/bin/env bash
exec /usr/local/share/nmea_navsat_driver/venv/bin/python /usr/local/share/nmea_navsat_driver/catkin_virtualenv_scripts/test_driver.py "$@"
