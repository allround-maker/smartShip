#!/usr/bin/env bash
exec /home/ssf/catkin_ws/src/control_pkg/devel/share/nmea_navsat_driver/venv/bin/python /home/ssf/catkin_ws/src/nmea_navsat_driver/test/test_driver.py "$@"
