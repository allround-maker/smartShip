
"use strict";

let Ins = require('./Ins.js');

module.exports = {
  Ins: Ins,
};
