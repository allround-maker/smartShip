
"use strict";

let SrvTutorial = require('./SrvTutorial.js')

module.exports = {
  SrvTutorial: SrvTutorial,
};
