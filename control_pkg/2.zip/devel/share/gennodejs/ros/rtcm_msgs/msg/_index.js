
"use strict";

let Message = require('./Message.js');

module.exports = {
  Message: Message,
};
