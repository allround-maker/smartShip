# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/ssf/catkin_ws/src/ddynamic_reconfigure/include".split(';') if "/home/ssf/catkin_ws/src/ddynamic_reconfigure/include" != "" else []
PROJECT_CATKIN_DEPENDS = "roscpp;dynamic_reconfigure".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-lddynamic_reconfigure".split(';') if "-lddynamic_reconfigure" != "" else []
PROJECT_NAME = "ddynamic_reconfigure"
PROJECT_SPACE_DIR = "/home/ssf/catkin_ws/src/control_pkg/devel"
PROJECT_VERSION = "0.4.1"
