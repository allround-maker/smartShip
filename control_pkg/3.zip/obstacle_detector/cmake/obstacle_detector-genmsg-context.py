# generated from genmsg/cmake/pkg-genmsg.context.in

messages_str = "/home/ssf/catkin_ws/src/obstacle_detector/msg/CircleObstacle.msg;/home/ssf/catkin_ws/src/obstacle_detector/msg/SegmentObstacle.msg;/home/ssf/catkin_ws/src/obstacle_detector/msg/Obstacles.msg"
services_str = ""
pkg_name = "obstacle_detector"
dependencies_str = "std_msgs;geometry_msgs"
langs = "gencpp;geneus;genlisp;gennodejs;genpy"
dep_include_paths_str = "obstacle_detector;/home/ssf/catkin_ws/src/obstacle_detector/msg;std_msgs;/opt/ros/melodic/share/std_msgs/cmake/../msg;geometry_msgs;/opt/ros/melodic/share/geometry_msgs/cmake/../msg"
PYTHON_EXECUTABLE = "/usr/bin/python2"
package_has_static_sources = '' == 'TRUE'
genmsg_check_deps_script = "/opt/ros/melodic/share/genmsg/cmake/../../../lib/genmsg/genmsg_check_deps.py"
