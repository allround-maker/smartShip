# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/ssf/catkin_ws/src/control_pkg/devel/include;/home/ssf/catkin_ws/src/obstacle_detector/include".split(';') if "/home/ssf/catkin_ws/src/control_pkg/devel/include;/home/ssf/catkin_ws/src/obstacle_detector/include" != "" else []
PROJECT_CATKIN_DEPENDS = "roscpp;std_msgs;geometry_msgs;sensor_msgs;visualization_msgs;tf;message_runtime".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-lobstacle_detector".split(';') if "-lobstacle_detector" != "" else []
PROJECT_NAME = "obstacle_detector"
PROJECT_SPACE_DIR = "/home/ssf/catkin_ws/src/control_pkg/devel"
PROJECT_VERSION = "1.0.0"
