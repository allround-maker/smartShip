# generated from genmsg/cmake/pkg-genmsg.context.in

messages_str = "/home/ssf/catkin_ws/src/rtcm_msgs/msg/Message.msg"
services_str = ""
pkg_name = "rtcm_msgs"
dependencies_str = "std_msgs"
langs = "gencpp;geneus;genlisp;gennodejs;genpy"
dep_include_paths_str = "rtcm_msgs;/home/ssf/catkin_ws/src/rtcm_msgs/msg;std_msgs;/opt/ros/melodic/share/std_msgs/cmake/../msg"
PYTHON_EXECUTABLE = "/usr/bin/python2"
package_has_static_sources = '' == 'TRUE'
genmsg_check_deps_script = "/opt/ros/melodic/share/genmsg/cmake/../../../lib/genmsg/genmsg_check_deps.py"
