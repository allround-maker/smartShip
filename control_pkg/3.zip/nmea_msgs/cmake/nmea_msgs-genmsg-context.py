# generated from genmsg/cmake/pkg-genmsg.context.in

messages_str = "/home/ssf/catkin_ws/src/nmea_msgs/msg/Gpgga.msg;/home/ssf/catkin_ws/src/nmea_msgs/msg/Gpgsa.msg;/home/ssf/catkin_ws/src/nmea_msgs/msg/Gpgsv.msg;/home/ssf/catkin_ws/src/nmea_msgs/msg/GpgsvSatellite.msg;/home/ssf/catkin_ws/src/nmea_msgs/msg/Gprmc.msg;/home/ssf/catkin_ws/src/nmea_msgs/msg/Gpgst.msg;/home/ssf/catkin_ws/src/nmea_msgs/msg/Sentence.msg"
services_str = ""
pkg_name = "nmea_msgs"
dependencies_str = "std_msgs"
langs = "gencpp;geneus;genlisp;gennodejs;genpy"
dep_include_paths_str = "nmea_msgs;/home/ssf/catkin_ws/src/nmea_msgs/msg;std_msgs;/opt/ros/melodic/share/std_msgs/cmake/../msg"
PYTHON_EXECUTABLE = "/usr/bin/python2"
package_has_static_sources = '' == 'TRUE'
genmsg_check_deps_script = "/opt/ros/melodic/share/genmsg/cmake/../../../lib/genmsg/genmsg_check_deps.py"
