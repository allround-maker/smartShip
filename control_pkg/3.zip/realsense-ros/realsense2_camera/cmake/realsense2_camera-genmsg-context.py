# generated from genmsg/cmake/pkg-genmsg.context.in

messages_str = "/home/ssf/catkin_ws/src/realsense-ros/realsense2_camera/msg/IMUInfo.msg;/home/ssf/catkin_ws/src/realsense-ros/realsense2_camera/msg/Extrinsics.msg;/home/ssf/catkin_ws/src/realsense-ros/realsense2_camera/msg/Metadata.msg"
services_str = "/home/ssf/catkin_ws/src/realsense-ros/realsense2_camera/srv/DeviceInfo.srv"
pkg_name = "realsense2_camera"
dependencies_str = "sensor_msgs;std_msgs"
langs = "gencpp;geneus;genlisp;gennodejs;genpy"
dep_include_paths_str = "realsense2_camera;/home/ssf/catkin_ws/src/realsense-ros/realsense2_camera/msg;sensor_msgs;/opt/ros/melodic/share/sensor_msgs/cmake/../msg;std_msgs;/opt/ros/melodic/share/std_msgs/cmake/../msg;geometry_msgs;/opt/ros/melodic/share/geometry_msgs/cmake/../msg"
PYTHON_EXECUTABLE = "/usr/bin/python2"
package_has_static_sources = '' == 'TRUE'
genmsg_check_deps_script = "/opt/ros/melodic/share/genmsg/cmake/../../../lib/genmsg/genmsg_check_deps.py"
