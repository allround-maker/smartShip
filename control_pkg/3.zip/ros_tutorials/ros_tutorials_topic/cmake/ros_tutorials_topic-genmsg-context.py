# generated from genmsg/cmake/pkg-genmsg.context.in

messages_str = "/home/ssf/catkin_ws/src/ros_tutorials/ros_tutorials_topic/msg/MsgTutorial.msg"
services_str = ""
pkg_name = "ros_tutorials_topic"
dependencies_str = "std_msgs"
langs = "gencpp;geneus;genlisp;gennodejs;genpy"
dep_include_paths_str = "ros_tutorials_topic;/home/ssf/catkin_ws/src/ros_tutorials/ros_tutorials_topic/msg;std_msgs;/opt/ros/melodic/share/std_msgs/cmake/../msg"
PYTHON_EXECUTABLE = "/usr/bin/python2"
package_has_static_sources = '' == 'TRUE'
genmsg_check_deps_script = "/opt/ros/melodic/share/genmsg/cmake/../../../lib/genmsg/genmsg_check_deps.py"
