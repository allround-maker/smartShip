# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "${prefix}/include".split(';') if "${prefix}/include" != "" else []
PROJECT_CATKIN_DEPENDS = "std_msgs;roscpp".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-lros_tutorials_service".split(';') if "-lros_tutorials_service" != "" else []
PROJECT_NAME = "ros_tutorials_service"
PROJECT_SPACE_DIR = "/usr/local"
PROJECT_VERSION = "0.1.0"
