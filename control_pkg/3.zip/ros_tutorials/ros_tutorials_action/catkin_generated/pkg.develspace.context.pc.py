# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/ssf/catkin_ws/src/control_pkg/devel/include;/usr/include".split(';') if "/home/ssf/catkin_ws/src/control_pkg/devel/include;/usr/include" != "" else []
PROJECT_CATKIN_DEPENDS = "std_msgs;actionlib_msgs;actionlib;roscpp".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-lros_tutorials_action;/usr/lib/x86_64-linux-gnu/libboost_system.so".split(';') if "-lros_tutorials_action;/usr/lib/x86_64-linux-gnu/libboost_system.so" != "" else []
PROJECT_NAME = "ros_tutorials_action"
PROJECT_SPACE_DIR = "/home/ssf/catkin_ws/src/control_pkg/devel"
PROJECT_VERSION = "0.1.0"
