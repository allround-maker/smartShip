#include <ros/ros.h>
#include <opencv2/opencv.hpp>
#include <cv_bridge/cv_bridge.h>
#include <iostream>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>
#include <string>
#include "std_msgs/Float32.h"
using namespace std;
using namespace cv;

/*void setLabel(Mat& image, string str, vector<Point> contour)
{
    int fontface = FONT_HERSHEY_SIMPLEX;
    double scale = 0.5;
    int thickness = 1;
    int baseline = 0;

    Size text = getTextSize(str, fontface, scale, thickness, &baseline);
    Rect r = boundingRect(contour);

    Point pt(r.x + ((r.width - text.width) / 2), r.y + ((r.height + text.height) / 2));
    rectangle(image, pt + Point(0, baseline), pt + Point(text.width, -text.height), CV_RGB(200,200,200), FILLED);
    putText(image, str, pt, fontface, scale, CV_RGB(0,0,0), thickness, 8);
}*/

int main (int argc, char** argv){
	ros::init(argc, argv, "detect_cir_degree");

    ros::NodeHandle n;
    ros::Publisher chatter_pub = n.advertise<std_msgs::Float32>("degree_cir", 10);
    ros::Rate loop_rate(10);
    std_msgs::Float32 msg;
	
	cv::VideoCapture cap(4);	
	cv::Mat frame;

    int ddepth = CV_16S;
	
	if(cap.isOpened()){
		while(1){
			cap >> frame;

            int x1 = 0;
            int x2 = 1280;
            int y1 = 100;
            int y2 = 600;

            //frame = frame(Range(y1,y2), Range(x1, x2));

            cv::cvtColor(frame,frame, cv::COLOR_RGB2BGR);
            cv::cvtColor(frame,frame, cv::COLOR_BGR2HSV);

            cv::Scalar lower_blue = cv::Scalar(35,60,70);
            cv::Scalar upper_blue = cv::Scalar(89,255,255);

            cv::inRange(frame, lower_blue, upper_blue, frame);

            //cv::cvtColor(frame, frame, cv::COLOR_BGR2GRAY);
            //cout << frame.channels() << endl;
			//cv::imshow("streaming_video", frame);

            cv::Mat scharr_x, scharr_y;

            cv::Scharr(frame, scharr_x, ddepth, 1,0);
            cv::Scharr(frame, scharr_y, ddepth, 0,1);

            cv::Mat Canny_frame;
            
            cv::Canny(scharr_x, scharr_y, frame, 500, 1000);

            //cv::imshow("Canny", Canny_frame);

            vector<vector<Point> > contours;
            findContours(frame, contours, RETR_LIST, CHAIN_APPROX_SIMPLE);

            //cout << contours.size()<<endl;

            cv::Mat frame_result;
            vector<Point2f> approx;

            frame_result = frame.clone();

            vector<Moments> mu(contours.size());
            for (int i =0; i < contours.size(); i++)
            {
                mu[i] = moments(contours[i], false);
            }

            vector<Point2f> mc(contours.size());
            for (int i =0; i < contours.size(); i++)
            {
                mc[i] = Point2f(mu[i].m10/mu[i].m00,mu[i].m01/mu[i].m00);
            }
            
            
            for (size_t i =0; i < contours.size(); i++)
            {   //cout<<"ContourArea : " <<contours.size()<<endl;
                approxPolyDP(Mat(contours[i]), approx, arcLength(Mat(contours[i]), true)*0.02, true);
                float degree = ((640 - mu[i].m10/mu[i].m00) * 0.078);

                



                if (fabs(contourArea(Mat(approx))) > 1000)
                {   //cout <<"ContourArea : " << fabs(contourArea(Mat(contours[i]))) << endl;
                    int size = approx.size();
                    if (size%2 ==0)
                    {
                        line(frame_result, approx[0], approx[approx.size()-1], Scalar(0,255,0),3);

                        for (int k=0; k<size-1; k++)
                            line(frame_result, approx[k], approx[k+1], Scalar(0,255,0),3);

                        for (int k=0; k<size; k++)
                            circle(frame_result, approx[k], 3, Scalar(0,0,255));

                    }
                    else {
                        line(frame_result, approx[0], approx[approx.size()-1], Scalar(0,255,0),3);

                        for (int k=0; k<size-1; k++)
                            line(frame_result, approx[k], approx[k+1], Scalar(0,255,0), 3);
                        for (int k=0; k<size; k++)
                            circle(frame_result, approx[k],3, Scalar(0,0,255));
                    }

                    if (size == 3);
                    //setLabel(frame_result, "Triangle", contours[i]);

                    else if (size == 4);
                    //setLabel(frame_result, "Rectangle", contours[i]);

                    else
                    //setLabel(frame_result, "Circle", contours[i]);
                    circle(frame_result, mc[i], 4, Scalar(0,255,0), -1,8,0);
                    //cout << "moments : " << mc[i] << endl;
                    //cout << "degree : "<< degree << endl;
                    msg.data = degree;
                    
                    //ROS_INFO("%f", msg.data);

                    chatter_pub.publish(msg);

                    ros::spinOnce();
                    loop_rate.sleep();


                }
            }

		}
	}
	
	else{
		std::cout << "NO FRAME, CHECK YOUR CAMERA!" << std::endl;
	}	
	
	cv::destroyAllWindows();
	
	return 0;
}#include <ros/ros.h>
#include <opencv2/opencv.hpp>
#include <cv_bridge/cv_bridge.h>
#include <iostream>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>
#include <string>
#include "std_msgs/Float32.h"
using namespace std;
using namespace cv;

/*void setLabel(Mat& image, string str, vector<Point> contour)
{
    int fontface = FONT_HERSHEY_SIMPLEX;
    double scale = 0.5;
    int thickness = 1;
    int baseline = 0;

    Size text = getTextSize(str, fontface, scale, thickness, &baseline);
    Rect r = boundingRect(contour);

    Point pt(r.x + ((r.width - text.width) / 2), r.y + ((r.height + text.height) / 2));
    rectangle(image, pt + Point(0, baseline), pt + Point(text.width, -text.height), CV_RGB(200,200,200), FILLED);
    putText(image, str, pt, fontface, scale, CV_RGB(0,0,0), thickness, 8);
}*/

int main (int argc, char** argv){
	ros::init(argc, argv, "detect_cir_degree");

    ros::NodeHandle n;
    ros::Publisher chatter_pub = n.advertise<std_msgs::Float32>("degree_cir", 10);
    ros::Rate loop_rate(10);
    std_msgs::Float32 msg;
	
	cv::VideoCapture cap(4);	
	cv::Mat frame;

    int ddepth = CV_16S;
	
	if(cap.isOpened()){
		while(1){
			cap >> frame;

            int x1 = 0;
            int x2 = 1280;
            int y1 = 100;
            int y2 = 600;

            //frame = frame(Range(y1,y2), Range(x1, x2));

            cv::cvtColor(frame,frame, cv::COLOR_RGB2BGR);
            cv::cvtColor(frame,frame, cv::COLOR_BGR2HSV);

            cv::Scalar lower_blue = cv::Scalar(35,60,70);
            cv::Scalar upper_blue = cv::Scalar(89,255,255);

            cv::inRange(frame, lower_blue, upper_blue, frame);

            //cv::cvtColor(frame, frame, cv::COLOR_BGR2GRAY);
            //cout << frame.channels() << endl;
			//cv::imshow("streaming_video", frame);

            cv::Mat scharr_x, scharr_y;

            cv::Scharr(frame, scharr_x, ddepth, 1,0);
            cv::Scharr(frame, scharr_y, ddepth, 0,1);

            cv::Mat Canny_frame;
            
            cv::Canny(scharr_x, scharr_y, frame, 500, 1000);

            //cv::imshow("Canny", Canny_frame);

            vector<vector<Point> > contours;
            findContours(frame, contours, RETR_LIST, CHAIN_APPROX_SIMPLE);

            //cout << contours.size()<<endl;

            cv::Mat frame_result;
            vector<Point2f> approx;

            frame_result = frame.clone();

            vector<Moments> mu(contours.size());
            for (int i =0; i < contours.size(); i++)
            {
                mu[i] = moments(contours[i], false);
            }

            vector<Point2f> mc(contours.size());
            for (int i =0; i < contours.size(); i++)
            {
                mc[i] = Point2f(mu[i].m10/mu[i].m00,mu[i].m01/mu[i].m00);
            }
            
            
            for (size_t i =0; i < contours.size(); i++)
            {   //cout<<"ContourArea : " <<contours.size()<<endl;
                approxPolyDP(Mat(contours[i]), approx, arcLength(Mat(contours[i]), true)*0.02, true);
                float degree = ((640 - mu[i].m10/mu[i].m00) * 0.078);

                



                if (fabs(contourArea(Mat(approx))) > 1000)
                {   //cout <<"ContourArea : " << fabs(contourArea(Mat(contours[i]))) << endl;
                    int size = approx.size();
                    if (size%2 ==0)
                    {
                        line(frame_result, approx[0], approx[approx.size()-1], Scalar(0,255,0),3);

                        for (int k=0; k<size-1; k++)
                            line(frame_result, approx[k], approx[k+1], Scalar(0,255,0),3);

                        for (int k=0; k<size; k++)
                            circle(frame_result, approx[k], 3, Scalar(0,0,255));

                    }
                    else {
                        line(frame_result, approx[0], approx[approx.size()-1], Scalar(0,255,0),3);

                        for (int k=0; k<size-1; k++)
                            line(frame_result, approx[k], approx[k+1], Scalar(0,255,0), 3);
                        for (int k=0; k<size; k++)
                            circle(frame_result, approx[k],3, Scalar(0,0,255));
                    }

                    if (size == 3);
                    //setLabel(frame_result, "Triangle", contours[i]);

                    else if (size == 4);
                    //setLabel(frame_result, "Rectangle", contours[i]);

                    else
                    //setLabel(frame_result, "Circle", contours[i]);
                    circle(frame_result, mc[i], 4, Scalar(0,255,0), -1,8,0);
                    //cout << "moments : " << mc[i] << endl;
                    //cout << "degree : "<< degree << endl;
                    msg.data = degree;
                    
                    //ROS_INFO("%f", msg.data);

                    chatter_pub.publish(msg);

                    ros::spinOnce();
                    loop_rate.sleep();


                }
            }

		}
	}
	
	else{
		std::cout << "NO FRAME, CHECK YOUR CAMERA!" << std::endl;
	}	
	
	cv::destroyAllWindows();
	
	return 0;
}
