#include "ros/ros.h"
#include "sensor_msgs/LaserScan.h"
#include <iostream>
#include <vector>
#include <algorithm>
#include <stdio.h>
#include <limits.h>
#include <cmath>
#include <std_msgs/Float32MultiArray.h>
#include <std_msgs/Float32.h>
using namespace std;

void printVec(vector<float> input){
    for(auto i: input){
        cout<< i <<", " ;
    }
    cout<<endl;
}

class RidarDir
{
	private:
		ros::NodeHandle n_;
		ros::Subscriber sub_;
		ros::Publisher pub_;
	private:

		vector<float> Detecting(vector<float> Lidar_data, float MaDis)
		{
			vector<float> zero__;
			for(int i = 0; i < Lidar_data.size(); i++)
			{
				if(Lidar_data[i] <= 0.0001 || Lidar_data[i] > MaDis)
				{
					zero__.push_back(1);
				}
				else
				{
					zero__.push_back(0);
				}
			}
			return zero__;
		}

		vector<float> MakeMargin(vector<float> input_vec, int marginsize){
			vector<float> remove_index;
			int before_data = 0;
			for(int i=0; i<input_vec.size(); i++){
				if(before_data == 0 && input_vec[i]>=0.0001 ){
					for(int add=0; add < marginsize; add ++){
						remove_index.push_back(i+add);
					}
				}
				before_data = input_vec[i];
			}
			for(int i=input_vec.size(); i>0; i--){
				if(before_data == 0 && input_vec[i]>=0.0001 ){
					for(int add=0; add < marginsize; add++){
						if(i-add>0){
							remove_index.push_back(i-add);
						}
						
					}
				}
				before_data = input_vec[i];
			}
			//printVec(remove_index);
			for(auto i: remove_index){
				input_vec[i]=0;
			}
			return input_vec;
		}

		vector<float> Area_calculation(vector<float> savezone)
		{
			vector<float> sum;
			sum.push_back (savezone[0]);
			for(int i = 1; i < savezone.size(); i++)
			{
				if(savezone[i] == 1)
				{
					sum.push_back (sum[i-1] + 1);
				}
				else
				{
					sum.push_back (0);
				}
			}
			return sum;
		}

		vector<float> MakeGroupArray(vector<float> input_vec){
			vector<float> output_vec;
			vector<float> my_vec = input_vec;
			my_vec.push_back(0);
			float before_data = 0;
			for(int i=0; i<my_vec.size(); i++)
			{
				if (my_vec[i]==0 && before_data!=0)
				{
					output_vec[i-1]=before_data;
					output_vec.push_back(0);
				}
				else if(my_vec[i]==1 && before_data==0)
				{
					output_vec.push_back(1);
				}
				else
				{
					output_vec.push_back(0);
				}
				before_data=my_vec[i];
			}
			output_vec.pop_back();
			return output_vec;
		}

		vector<float> Angle(vector<float> input_direction)
		{
			vector<float> direction_angle;
			float angle = 0;
			float a;
			float b;
			for(float i = 0; i < input_direction.size(); i++)
			{
				if(input_direction[i] == 0 );
				else
				{
					a = 0.7128712871;
					b = i;
					if(i >= input_direction.size()/2)
					{
						b = i - input_direction.size()/2;
					}
					angle = a * b;
					if(i < input_direction.size()/2)
					{
						angle = -180 + (a * b);
					}
					direction_angle.push_back (angle);
				}
			}
			
			return direction_angle;
		}

		vector<float> AbsVec(vector<float> Input_vec, int edit_num){
			vector<float> nums;
			for (float i=0; i < Input_vec.size(); i++) {
			  nums.push_back(abs(Input_vec[i] - edit_num));
			}
			//cout<< "input_vec" << endl;
			//printVec(Input_vec);

			for (float element : nums) 
			
			return nums;
		}

		vector<float> Min_Degree(vector<float> nums, vector<float>DirectionAngle)
		{
			vector<float> tums;
			float min = *min_element(nums.begin(), nums.end());
			//cout << "min : " << min << endl;

			float min_index = min_element(nums.begin(), nums.end()) - nums.begin();
			//cout << "min index : " << min_index << endl;
			//tums.push_back(min);
			//tums.push_back(min_index);
			tums.push_back(DirectionAngle[min_index]);
			return tums;
		}
		
		vector<float> Distingish(vector<float> Input)
		{
			vector<float> result = {0};
			for(int i =0; i<Input.size(); i++)
			{
				if(Input[i] == 0)
				{
					result[0] = 0;
				}
				else
				{
					result[0] = Input[i];
				}
			}
			return result;
		}

		float FindDir(vector<float> ukiss, float target_dir,float MaDis)
		{
			
			vector<float> myzero = Detecting(ukiss, MaDis);
			vector<float> Result = Distingish(myzero);
			vector<float> tums;
			if(Result[0] != 0)
			{	
				vector<float> input_vec = MakeMargin(myzero, 1);
				vector<float> mysum = Area_calculation(input_vec);
				vector<float> direction_angle = Angle(mysum);
				vector<float> nums = AbsVec(direction_angle, target_dir);
				tums = Min_Degree(nums, direction_angle);
			}
			else
			{
				tums[0] = Result[0];
			}
			return tums[0];
		}
		 
		/*float FindDir(vector<float> ukiss, float target_dir,float MaDis)
		{
			vector<float> myzero = Detecting(ukiss, MaDis);
			//vector<float> result = Distingish(myzero);
			//vector<float> tums;
			vector<float> input_vec = MakeMargin(myzero, 1);
			vector<float> mysum = Area_calculation(input_vec);
			vector<float> direction_angle = Angle(mysum);
			vector<float> nums = AbsVec(direction_angle, target_dir);
			//tums = Min_Degree(nums, direction_angle);
			vector<float> tums = Min_Degree(nums, direction_angle);
			return tums[0];
		}*/
		
			
	public:
		RidarDir(){
			sub_ = n_.subscribe("/scan", 10, &RidarDir::scanCallback, this);
			pub_ = n_.advertise<std_msgs::Float32>("/Direction_for_avoid", 1000);
		}
		void scanCallback(const sensor_msgs::LaserScan::ConstPtr& scan)
		{
			std_msgs::Float32MultiArray dis_arr;
			dis_arr.data = scan->ranges;
			std_msgs::Float32 output;
			float ST_DR;
			float VS;
			n_.getParam("/listener/ST_DR", ST_DR);
			n_.getParam("/listener/Visibility", VS);
			output.data = FindDir(dis_arr.data, ST_DR, VS);
			pub_.publish(output);
			//(스캔값, 기준방향, 가시거리)
		}
	
		
};


int main(int argc, char **argv){

   ros::init(argc, argv, "listener");
   RidarDir RD;   
   ros::spin();
   
   return 0;
}
